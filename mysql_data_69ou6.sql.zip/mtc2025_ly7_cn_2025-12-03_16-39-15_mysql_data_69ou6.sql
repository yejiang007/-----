-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: mtc2025_ly7_cn
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cmx_display_control`
--

DROP TABLE IF EXISTS `cmx_display_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmx_display_control` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_type` varchar(50) NOT NULL COMMENT '显示类型 (player, ranking, etc.)',
  `target_id` int(11) DEFAULT NULL COMMENT '目标ID (e.g., player_id)',
  `group_id` int(11) DEFAULT NULL COMMENT '分组ID (可选)',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='前端显示控制表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmx_display_control`
--

LOCK TABLES `cmx_display_control` WRITE;
/*!40000 ALTER TABLE `cmx_display_control` DISABLE KEYS */;
INSERT INTO `cmx_display_control` VALUES (1,'player',116,0,'2025-12-03 16:05:33');
/*!40000 ALTER TABLE `cmx_display_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmx_groups`
--

DROP TABLE IF EXISTS `cmx_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmx_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '分组唯一标识ID',
  `group_name` varchar(50) NOT NULL COMMENT '分组名称',
  `group_code` varchar(20) NOT NULL COMMENT '分组编码',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '分组状态：1-赛事中，2-已结束，0-未开始',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `uniq_group_name` (`group_name`),
  UNIQUE KEY `uniq_group_code` (`group_code`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='CMX 分组信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmx_groups`
--

LOCK TABLES `cmx_groups` WRITE;
/*!40000 ALTER TABLE `cmx_groups` DISABLE KEYS */;
INSERT INTO `cmx_groups` VALUES (1,'85cc青少年组','85CC-J',1,'2025-12-03 08:28:41'),(2,'250cc公开组','250CC-O',1,'2025-12-03 08:28:41'),(3,'450cc专业组','450CC-P',0,'2025-12-03 08:28:41');
/*!40000 ALTER TABLE `cmx_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmx_players`
--

DROP TABLE IF EXISTS `cmx_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmx_players` (
  `player_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '选手唯一标识ID',
  `player_name` varchar(50) NOT NULL COMMENT '选手名称',
  `avatar_url` varchar(255) NOT NULL COMMENT '选手头像URL（已统一为 https://mtc2025.ly7.cn/img/img.png）',
  `car_number` varchar(20) NOT NULL COMMENT '车号（赛事内唯一）',
  `nationality` varchar(30) NOT NULL COMMENT '国籍（统一中文表述）',
  `team_name` varchar(100) NOT NULL COMMENT '车队名称',
  `entry_number` varchar(20) NOT NULL COMMENT '参赛序号（全局唯一）',
  `entry_order` int(11) DEFAULT NULL COMMENT '出场顺序（同一分组内唯一，用于出场名单排序）',
  `group_id` int(11) NOT NULL COMMENT '分组ID（关联 cmx_groups）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`player_id`),
  UNIQUE KEY `uniq_car_number` (`car_number`),
  UNIQUE KEY `uniq_entry_number` (`entry_number`),
  KEY `idx_player_name` (`player_name`),
  KEY `idx_group_id` (`group_id`),
  KEY `idx_entry_order` (`group_id`,`entry_order`),
  CONSTRAINT `fk_players_group` FOREIGN KEY (`group_id`) REFERENCES `cmx_groups` (`group_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8mb4 COMMENT='CMX 选手信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmx_players`
--

LOCK TABLES `cmx_players` WRITE;
/*!40000 ALTER TABLE `cmx_players` DISABLE KEYS */;
INSERT INTO `cmx_players` VALUES (101,'张三','https://mtc2025.ly7.cn/img/img.png','88','中国','CMX青少年车队','CMX2025-085-001',1,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(102,'李强','https://mtc2025.ly7.cn/img/img.png','21','中国','岭南少年越野队','CMX2025-085-002',2,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(103,'Wang Hua','https://mtc2025.ly7.cn/img/img.png','66','中国','飞驰越野车队','CMX2025-085-003',3,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(104,'Chen Yu','https://mtc2025.ly7.cn/img/img.png','15','中国','星火青训车队','CMX2025-085-004',4,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(105,'Liu Kai','https://mtc2025.ly7.cn/img/img.png','37','中国','山地少年车队','CMX2025-085-005',5,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(106,'Li Ming','https://mtc2025.ly7.cn/img/img.png','99','中国','极速越野车队','CMX2025-085-006',6,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(107,'Zhao Rui','https://mtc2025.ly7.cn/img/img.png','52','中国','华北少年越野队','CMX2025-085-007',7,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(108,'Sun Hao','https://mtc2025.ly7.cn/img/img.png','73','中国','CMX青少年车队','CMX2025-085-008',8,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(109,'Lin Tao','https://mtc2025.ly7.cn/img/img.png','07','中国','星火青训车队','CMX2025-085-009',9,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(110,'Zhou Hang','https://mtc2025.ly7.cn/img/img.png','45','中国','飞驰越野车队','CMX2025-085-010',10,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(111,'Wu Bin','https://mtc2025.ly7.cn/img/img.png','33','中国','北京极速车队','CMX2025-85-011',11,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(112,'Xu Jun','https://mtc2025.ly7.cn/img/img.png','55','中国','上海越野俱乐部','CMX2025-85-012',12,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(113,'Ma Chao','https://mtc2025.ly7.cn/img/img.png','77','中国','广州越野车队','CMX2025-85-013',13,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(114,'Huang Wei','https://mtc2025.ly7.cn/img/img.png','19','中国','深圳飞驰车队','CMX2025-85-014',14,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(115,'Song Yang','https://mtc2025.ly7.cn/img/img.png','42','中国','成都山地车队','CMX2025-85-015',15,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(116,'Feng Lei','https://mtc2025.ly7.cn/img/img.png','64','中国','西安摩托协会','CMX2025-85-016',16,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(201,'John Doe','https://mtc2025.ly7.cn/img/img.png','18','美国','International Racing Team','CMX2025-250-001',1,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(202,'Tanaka','https://mtc2025.ly7.cn/img/img.png','28','日本','Samurai MX Team','CMX2025-250-002',2,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(203,'Alex Martin','https://mtc2025.ly7.cn/img/img.png','12','法国','Euro Speed MX','CMX2025-250-003',3,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(204,'Carlos Ruiz','https://mtc2025.ly7.cn/img/img.png','34','西班牙','Iberia Offroad','CMX2025-250-004',4,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(205,'Kevin Smith','https://mtc2025.ly7.cn/img/img.png','57','英国','London MX Club','CMX2025-250-005',5,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(206,'Matsuda','https://mtc2025.ly7.cn/img/img.png','72','日本','Samurai MX Team','CMX2025-250-006',6,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(207,'Luca Rossi','https://mtc2025.ly7.cn/img/img.png','39','意大利','Roma Racing','CMX2025-250-007',7,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(208,'Jack Brown','https://mtc2025.ly7.cn/img/img.png','63','澳大利亚','Sydney MX Squad','CMX2025-250-008',8,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(209,'Kim Min-su','https://mtc2025.ly7.cn/img/img.png','25','韩国','Seoul Riders','CMX2025-250-009',9,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(210,'Marco Silva','https://mtc2025.ly7.cn/img/img.png','91','巴西','Rio MX Team','CMX2025-250-010',10,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(211,'Tom Wilson','https://mtc2025.ly7.cn/img/img.png','14','加拿大','Maple MX','CMX2025-250-011',11,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(212,'Yamamoto','https://mtc2025.ly7.cn/img/img.png','36','日本','Samurai MX Team','CMX2025-250-012',12,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(213,'Pierre Dubois','https://mtc2025.ly7.cn/img/img.png','48','法国','Euro Speed MX','CMX2025-250-013',13,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(214,'Miguel Torres','https://mtc2025.ly7.cn/img/img.png','59','西班牙','Iberia Offroad','CMX2025-250-014',14,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(215,'James Taylor','https://mtc2025.ly7.cn/img/img.png','71','英国','London MX Club','CMX2025-250-015',15,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(216,'Lee Ji-hoon','https://mtc2025.ly7.cn/img/img.png','83','韩国','Seoul Riders','CMX2025-250-016',16,2,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(301,'Zhang Wei','https://mtc2025.ly7.cn/img/img.png','101','中国','CMX Pro Team','CMX2025-450-001',1,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(302,'Han Lei','https://mtc2025.ly7.cn/img/img.png','102','中国','华北专业队','CMX2025-450-002',2,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(303,'Guo Feng','https://mtc2025.ly7.cn/img/img.png','103','中国','川渝越野联队','CMX2025-450-003',3,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(304,'Liang Bo','https://mtc2025.ly7.cn/img/img.png','104','中国','岭南职业车队','CMX2025-450-004',4,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(305,'Peter Hall','https://mtc2025.ly7.cn/img/img.png','105','美国','Factory MX USA','CMX2025-450-005',5,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(306,'Sato Ken','https://mtc2025.ly7.cn/img/img.png','106','日本','Tokyo Pro MX','CMX2025-450-006',6,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(307,'Jean Dupont','https://mtc2025.ly7.cn/img/img.png','107','法国','Paris Factory MX','CMX2025-450-007',7,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(308,'Muller','https://mtc2025.ly7.cn/img/img.png','108','德国','Berlin Racing','CMX2025-450-008',8,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(309,'Oscar Lopez','https://mtc2025.ly7.cn/img/img.png','109','西班牙','Iberia Pro MX','CMX2025-450-009',9,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(310,'David King','https://mtc2025.ly7.cn/img/img.png','110','英国','London Factory Team','CMX2025-450-010',10,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(311,'Yang Jun','https://mtc2025.ly7.cn/img/img.png','111','中国','华南专业队','CMX2025-450-011',11,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(312,'Zhu Gang','https://mtc2025.ly7.cn/img/img.png','112','中国','华东职业车队','CMX2025-450-012',12,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(313,'Robert White','https://mtc2025.ly7.cn/img/img.png','113','美国','Factory MX USA','CMX2025-450-013',13,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(314,'Hiroshi','https://mtc2025.ly7.cn/img/img.png','114','日本','Tokyo Pro MX','CMX2025-450-014',14,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(315,'Francois','https://mtc2025.ly7.cn/img/img.png','115','法国','Paris Factory MX','CMX2025-450-015',15,3,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(316,'Schmidt','https://mtc2025.ly7.cn/img/img.png','116','德国','Berlin Racing','CMX2025-450-016',16,3,'2025-12-03 08:28:41','2025-12-03 08:28:41');
/*!40000 ALTER TABLE `cmx_players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmx_realtime_ranking`
--

DROP TABLE IF EXISTS `cmx_realtime_ranking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmx_realtime_ranking` (
  `ranking_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '排名记录唯一ID',
  `player_id` int(11) NOT NULL COMMENT '选手ID（关联 cmx_players）',
  `group_id` int(11) NOT NULL COMMENT '分组ID（关联 cmx_groups）',
  `current_rank` int(11) NOT NULL COMMENT '当前排名（1 为第一名）',
  `lap_time` decimal(10,2) DEFAULT NULL COMMENT '最新圈速(秒)',
  `gap_time` decimal(10,2) DEFAULT NULL COMMENT '与领先者时间差(秒)',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '排名更新时间',
  PRIMARY KEY (`ranking_id`),
  UNIQUE KEY `uniq_player_group` (`player_id`,`group_id`),
  KEY `idx_player_id` (`player_id`),
  KEY `idx_group_update` (`group_id`,`update_time`),
  CONSTRAINT `fk_ranking_group` FOREIGN KEY (`group_id`) REFERENCES `cmx_groups` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ranking_player` FOREIGN KEY (`player_id`) REFERENCES `cmx_players` (`player_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4 COMMENT='CMX 实时排名表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmx_realtime_ranking`
--

LOCK TABLES `cmx_realtime_ranking` WRITE;
/*!40000 ALTER TABLE `cmx_realtime_ranking` DISABLE KEYS */;
INSERT INTO `cmx_realtime_ranking` VALUES (1,101,1,1,95.23,0.00,'2025-12-03 14:27:25'),(2,102,1,3,95.80,0.57,'2025-12-03 16:05:13'),(3,103,1,2,96.12,0.89,'2025-12-03 16:05:13'),(4,104,1,4,96.75,1.52,'2025-12-03 13:02:34'),(5,105,1,5,97.30,2.07,'2025-12-03 13:02:34'),(6,106,1,6,97.85,2.62,'2025-12-03 13:02:34'),(7,107,1,8,98.10,2.87,'2025-12-03 16:05:19'),(8,108,1,7,98.65,3.42,'2025-12-03 16:05:20'),(9,109,1,9,99.20,3.97,'2025-12-03 13:02:34'),(10,110,1,10,99.75,4.52,'2025-12-03 13:02:34'),(11,201,2,1,92.50,0.00,'2025-05-20 14:31:10'),(12,202,2,2,93.10,0.60,'2025-05-20 14:31:10'),(13,203,2,3,93.45,0.95,'2025-05-20 14:31:11'),(14,204,2,4,93.80,1.30,'2025-05-20 14:31:11'),(15,205,2,5,94.15,1.65,'2025-05-20 14:31:12'),(16,206,2,6,94.60,2.10,'2025-05-20 14:31:12'),(17,207,2,7,95.00,2.50,'2025-05-20 14:31:13'),(18,208,2,8,95.35,2.85,'2025-05-20 14:31:13'),(19,209,2,9,95.80,3.30,'2025-05-20 14:31:14'),(20,210,2,10,96.20,3.70,'2025-05-20 14:31:14'),(21,301,3,1,90.10,0.00,'2025-05-20 14:32:00'),(22,302,3,2,90.45,0.35,'2025-05-20 14:32:00'),(23,303,3,3,90.80,0.70,'2025-05-20 14:32:01'),(24,304,3,4,91.10,1.00,'2025-05-20 14:32:01'),(25,305,3,5,91.50,1.40,'2025-05-20 14:32:02'),(26,306,3,6,91.85,1.75,'2025-05-20 14:32:02'),(27,307,3,7,92.20,2.10,'2025-05-20 14:32:03'),(28,308,3,8,92.55,2.45,'2025-05-20 14:32:03'),(29,309,3,9,92.95,2.85,'2025-05-20 14:32:04'),(30,310,3,10,93.30,3.20,'2025-05-20 14:32:04'),(31,111,1,12,100.30,5.07,'2025-12-03 14:21:40'),(32,112,1,11,100.85,5.62,'2025-12-03 14:21:40'),(33,113,1,13,101.40,6.17,'2025-12-03 13:02:34'),(34,114,1,16,101.95,6.72,'2025-12-03 14:27:32'),(35,115,1,14,102.50,7.27,'2025-12-03 14:21:32'),(36,116,1,15,103.05,7.82,'2025-12-03 14:27:32'),(37,211,2,11,96.65,4.15,'2025-05-20 14:31:15'),(38,212,2,12,97.10,4.60,'2025-05-20 14:31:15'),(39,213,2,13,97.55,5.05,'2025-05-20 14:31:16'),(40,214,2,14,98.00,5.50,'2025-05-20 14:31:16'),(41,215,2,15,98.45,5.95,'2025-05-20 14:31:17'),(42,216,2,16,98.90,6.40,'2025-05-20 14:31:17'),(43,311,3,11,93.70,3.60,'2025-05-20 14:32:05'),(44,312,3,12,94.10,4.00,'2025-05-20 14:32:05'),(45,313,3,13,94.50,4.40,'2025-05-20 14:32:06'),(46,314,3,14,94.90,4.80,'2025-05-20 14:32:06'),(47,315,3,15,95.30,5.20,'2025-05-20 14:32:07'),(48,316,3,16,95.70,5.60,'2025-05-20 14:32:07');
/*!40000 ALTER TABLE `cmx_realtime_ranking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmx_sponsors`
--

DROP TABLE IF EXISTS `cmx_sponsors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmx_sponsors` (
  `sponsor_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '赞助商唯一标识ID',
  `sponsor_name` varchar(100) NOT NULL COMMENT '赞助商名称',
  `logo_url` varchar(255) NOT NULL COMMENT 'Logo图片URL',
  `display_order` int(11) DEFAULT '0' COMMENT '显示顺序（数字越小越靠前）',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：1-显示，0-隐藏',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`sponsor_id`),
  KEY `idx_display_order` (`display_order`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COMMENT='CMX 赞助商信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmx_sponsors`
--

LOCK TABLES `cmx_sponsors` WRITE;
/*!40000 ALTER TABLE `cmx_sponsors` DISABLE KEYS */;
INSERT INTO `cmx_sponsors` VALUES (1,'Masontex','https://cdn.cmx.com/sponsors/masontex.png',1,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(2,'SULAITE','https://cdn.cmx.com/sponsors/sulaite.png',2,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(3,'SOMAN','https://cdn.cmx.com/sponsors/soman.png',3,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(4,'WOLF HUNTING','https://cdn.cmx.com/sponsors/wolf-hunting.png',4,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(5,'XIN-DL','https://cdn.cmx.com/sponsors/xin-dl.png',5,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(6,'JXT WOLF','https://cdn.cmx.com/sponsors/jxt-wolf.png',6,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(7,'CROWNHOMES','https://cdn.cmx.com/sponsors/crownhomes.png',7,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(8,'UTV FAMILY','https://cdn.cmx.com/sponsors/utv-family.png',8,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(9,'CAMF','https://cdn.cmx.com/sponsors/camf.png',9,1,'2025-12-03 08:28:41','2025-12-03 08:28:41'),(10,'KIKAS','https://cdn.cmx.com/sponsors/kikas.png',10,1,'2025-12-03 08:28:41','2025-12-03 08:28:41');
/*!40000 ALTER TABLE `cmx_sponsors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mtc2025_ly7_cn'
--

--
-- Dumping routines for database 'mtc2025_ly7_cn'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03 16:39:15
